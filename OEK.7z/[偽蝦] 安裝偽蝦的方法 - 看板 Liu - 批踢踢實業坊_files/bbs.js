(function() {

var $ = jQuery;

var ErrArticleModified = '原文已被修改，請嘗試重新載入此頁';
var ErrNetwork = '無法更新推文';

function attachPoller(div) {
    var timer = null;
    var autoScroll = false;
    var autoUpdate = false;
    var lastModified = null;
    var currSize = parseInt(div.attr('data-offset'));
    var longPollUrl = div.attr('data-longpollurl');
    var pollUrl = div.attr('data-pollurl');
    var currReq = null;
    var fatalError = null;

    function scheduleNextPoll() {
        if (timer) {
            window.clearTimeout(timer);
            timer = null;
        }
        timer = window.setTimeout(longPoll, 1000);
    }

    function longPoll() {
        var headers = {};
        if (lastModified != null) {
            headers['If-Modified-Since'] = lastModified;
        }
        currReq = $.ajax({
            url: longPollUrl,
            headers: headers,
            timeout: 28000
        }).success(function(data, textStatus, req) {
            currReq = null;
            console.log(data);
            lastModified = req.getResponseHeader('Last-Modified');
            if (data.size > currSize) {
                requestContent(data.size, data.sig);
            } else {
                scheduleNextPoll();
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            currReq = null;
            if (textStatus === 'timeout') {
                scheduleNextPoll();
            } else if (textStatus !== 'abort') {
                setFatalError(ErrNetwork);
            }
        });
    }

    function requestContent(size, sig) {
        currSize = size;
        var url = pollUrl
            + '&size=' + encodeURIComponent(size.toString())
            + '&size-sig=' + encodeURIComponent(sig);
        $.ajax(url).success(function(data) {
            console.log(data);
            if (data.success) {
                receivedPushContent(data.contentHtml);
                pollUrl = data.pollUrl;
                scheduleNextPoll();
            } else {
                setFatalError(ErrArticleModified);
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            setFatalError(ErrNetwork);
        });
    }

    function receivedPushContent(contentHtml) {
        if (contentHtml.length > 0) {
            $('#main-content').append(
                    $('<div>').html(contentHtml).addClass('new-push'));
            if (autoScroll)
                $(document.body).animate({scrollTop: document.body.clientHeight - window.innerHeight}, 500);
        }
    }

    function setAutoUpdate(enabled) {
        if (currReq != null) {
            currReq.abort();
            currReq = null;
        }
        if (enabled) {
            scheduleNextPoll();
        } else if (timer) {
            window.clearTimeout(timer);
            timer = null;
        }
        autoUpdate = enabled;
        autoScroll = enabled;
        updateStatus();
    }

    function toggleAuto() {
        if (fatalError != null) {
            return;
        }
        setAutoUpdate(!autoUpdate);
    }

    function updateStatus() {
        if (fatalError != null) {
            div.text(fatalError);
            div.addClass('fatal-error');
            return;
        }
        div.text('推文' + (autoUpdate ?
                    ('會自動更新，並' + (autoScroll ? '會' : '不會') + '自動捲動')
                    : '自動更新已關閉'));
    }

    function setFatalError(msg) {
        fatalError = msg;
        updateStatus();
    }

    div.click(toggleAuto);
    setAutoUpdate(false);
}

$(document).ready(function() {
    attachPoller($('#article-polling'));
});

})();
